An example package.  Build a wheel from this with `pyproject-build`.
