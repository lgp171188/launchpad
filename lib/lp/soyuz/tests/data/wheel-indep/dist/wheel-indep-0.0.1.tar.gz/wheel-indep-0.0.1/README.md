An example project.  Build a wheel from this with `pyproject-build -w`.
